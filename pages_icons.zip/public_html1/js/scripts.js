/*!
    * Start Bootstrap - Freelancer v6.0.4 (https://startbootstrap.com/themes/freelancer)
    * Copyright 2013-2020 Start Bootstrap
    * Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-freelancer/blob/master/LICENSE)
    */
(function($) {
  $('#countdown').countdown({
    
        year: 2020,// YYYY Format
    
        month: 9,// 1-12
    
        day: 8,// 1-31
    
        hour: 12,// 24 hour format 0-23
    
        minute: 0,// 0-59
    
        second: 0,// 0-59
        
        timezone: -7

      });
    
})(jQuery); // End of use strict
  